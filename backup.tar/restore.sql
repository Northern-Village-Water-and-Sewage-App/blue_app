--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.12 (Ubuntu 10.12-0ubuntu0.18.04.1)
-- Dumped by pg_dump version 10.12 (Ubuntu 10.12-0ubuntu0.18.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.sewage_tank_readings DROP CONSTRAINT sewage_tank_readings_sewage_tanks_models_pk_fk;
ALTER TABLE ONLY public.sewage_tank_readings DROP CONSTRAINT sewage_tank_readings_residents_pk_fk;
ALTER TABLE ONLY public.residents DROP CONSTRAINT residents_water_tanks_model_pk_fk;
ALTER TABLE ONLY public.residents DROP CONSTRAINT residents_sewage_tanks_models_pk_fk;
ALTER TABLE ONLY public.reports DROP CONSTRAINT reports_complaint_types_pk_fk;
ALTER TABLE ONLY public.reports DROP CONSTRAINT reports_companies_pk_fk;
ALTER TABLE ONLY public.manager_worklist DROP CONSTRAINT manager_worklist_tank_types_pk_fk;
ALTER TABLE ONLY public.water_tank_readings DROP CONSTRAINT fk_tank_readings_tank_owner_fk;
ALTER TABLE ONLY public.water_tank_readings DROP CONSTRAINT fk_tank_readings_tank_models;
ALTER TABLE ONLY public.manager_worklist DROP CONSTRAINT fk_manager_worklist_time_estimate_fk;
ALTER TABLE ONLY public.manager_worklist DROP CONSTRAINT fk_manager_worklist_resident_fk;
DROP TRIGGER add_to_water_worklist ON public.water_tank_readings;
DROP TRIGGER add_to_sewage_worklist ON public.water_tank_readings;
DROP INDEX public.water_tanks_model_pk_uindex;
DROP INDEX public.sewage_tanks_models_pk_uindex;
DROP INDEX public.sewage_tank_readings_pk_uindex;
DROP INDEX public.residents_pk_uindex;
DROP INDEX public.residents_new_username_uindex;
DROP INDEX public.reports_pk_uindex;
DROP INDEX public.managers_pk_uindex;
DROP INDEX public.managers_new_username_uindex;
DROP INDEX public.drivers_pk_uindex;
DROP INDEX public.drivers_new_username_uindex;
DROP INDEX public.complaint_types_pk_uindex;
DROP INDEX public.companies_pk_uindex;
ALTER TABLE ONLY public.water_tanks_models DROP CONSTRAINT water_tanks_model_pk;
ALTER TABLE ONLY public.sewage_tanks_models DROP CONSTRAINT sewage_tanks_models_pk;
ALTER TABLE ONLY public.sewage_tank_readings DROP CONSTRAINT sewage_tank_readings_pk;
ALTER TABLE ONLY public.residents DROP CONSTRAINT residents_pk;
ALTER TABLE ONLY public.reports DROP CONSTRAINT reports_pk;
ALTER TABLE ONLY public.time_estimates DROP CONSTRAINT pk_time_estimates;
ALTER TABLE ONLY public.tank_types DROP CONSTRAINT pk_tank_types;
ALTER TABLE ONLY public.water_tank_readings DROP CONSTRAINT pk_tank_readings;
ALTER TABLE ONLY public.manager_worklist DROP CONSTRAINT pk_manager_worklist;
ALTER TABLE ONLY public.message DROP CONSTRAINT message_pk;
ALTER TABLE ONLY public.managers DROP CONSTRAINT managers_pk;
ALTER TABLE ONLY public.drivers DROP CONSTRAINT drivers_pk;
ALTER TABLE ONLY public.complaint_types DROP CONSTRAINT complaint_types_pk;
ALTER TABLE ONLY public.companies DROP CONSTRAINT companies_pk;
ALTER TABLE public.water_tanks_models ALTER COLUMN pk DROP DEFAULT;
ALTER TABLE public.water_tank_readings ALTER COLUMN pk DROP DEFAULT;
ALTER TABLE public.time_estimates ALTER COLUMN pk DROP DEFAULT;
ALTER TABLE public.tank_types ALTER COLUMN pk DROP DEFAULT;
ALTER TABLE public.sewage_tanks_models ALTER COLUMN pk DROP DEFAULT;
ALTER TABLE public.sewage_tank_readings ALTER COLUMN pk DROP DEFAULT;
ALTER TABLE public.residents ALTER COLUMN pk DROP DEFAULT;
ALTER TABLE public.reports ALTER COLUMN pk DROP DEFAULT;
ALTER TABLE public.message ALTER COLUMN pk DROP DEFAULT;
ALTER TABLE public.managers ALTER COLUMN pk DROP DEFAULT;
ALTER TABLE public.manager_worklist ALTER COLUMN pk DROP DEFAULT;
ALTER TABLE public.drivers ALTER COLUMN pk DROP DEFAULT;
ALTER TABLE public.complaint_types ALTER COLUMN pk DROP DEFAULT;
ALTER TABLE public.companies ALTER COLUMN pk DROP DEFAULT;
DROP SEQUENCE public.water_tanks_model_pk_seq;
DROP TABLE public.water_tanks_models;
DROP SEQUENCE public.time_estimates_pk_seq;
DROP SEQUENCE public.tank_types_pk_seq;
DROP SEQUENCE public.tank_readings_pk_seq;
DROP TABLE public.water_tank_readings;
DROP SEQUENCE public.sewage_tanks_models_pk_seq;
DROP TABLE public.sewage_tanks_models;
DROP SEQUENCE public.sewage_tank_readings_pk_seq;
DROP TABLE public.sewage_tank_readings;
DROP SEQUENCE public.residents_pk_seq;
DROP SEQUENCE public.reports_pk_seq;
DROP SEQUENCE public.message_pk_seq;
DROP TABLE public.message;
DROP SEQUENCE public.managers_pk_seq;
DROP SEQUENCE public.manager_worklist_pk_seq;
DROP SEQUENCE public.drivers_pk_seq;
DROP SEQUENCE public.complaint_types_pk_seq;
DROP SEQUENCE public.companies_pk_seq;
DROP VIEW public.app_worklist;
DROP TABLE public.time_estimates;
DROP TABLE public.tank_types;
DROP TABLE public.manager_worklist;
DROP VIEW public.app_reports;
DROP TABLE public.reports;
DROP TABLE public.complaint_types;
DROP TABLE public.companies;
DROP VIEW public.app_login;
DROP TABLE public.residents;
DROP TABLE public.managers;
DROP TABLE public.drivers;
DROP FUNCTION public.is_caution_level_water_level(reading_pk integer);
DROP FUNCTION public.is_caution_level_sewage_level(reading_pk integer);
DROP FUNCTION public.add_to_water_worklist();
DROP FUNCTION public.add_to_sewage_worklist();
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


--
-- Name: add_to_sewage_worklist(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.add_to_sewage_worklist() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
    if is_caution_level_sewage_level(new.pk) then
        insert into manager_worklist (time_estimate_fk, resident_fk, tank_type_fk)
        SELECT 6, u.pk, 2
        from sewage_tank_readings tr
                 join residents u on tr.tank_owner_fk = u.pk
        where tr.pk = new.pk;
    end if;
    return new;
end;
$$;


ALTER FUNCTION public.add_to_sewage_worklist() OWNER TO postgres;

--
-- Name: add_to_water_worklist(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.add_to_water_worklist() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
    if is_caution_level_water_level(new.pk) then
        insert into manager_worklist (time_estimate_fk, resident_fk, tank_type_fk)
        SELECT 6, u.pk, 1
        from water_tank_readings tr
                 join residents u on tr.tank_owner_fk = u.pk
        where tr.pk = new.pk;
    end if;
    return new;
end;
$$;


ALTER FUNCTION public.add_to_water_worklist() OWNER TO postgres;

--
-- Name: is_caution_level_sewage_level(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.is_caution_level_sewage_level(reading_pk integer) RETURNS TABLE(is_caution boolean)
    LANGUAGE plpgsql
    AS $$
begin
    return QUERY select tr.status = 'WARNING'
                 from sewage_tank_readings as tr 
                 where tr.pk = reading_pk;
end;
$$;


ALTER FUNCTION public.is_caution_level_sewage_level(reading_pk integer) OWNER TO postgres;

--
-- Name: is_caution_level_water_level(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.is_caution_level_water_level(reading_pk integer) RETURNS TABLE(is_caution boolean)
    LANGUAGE plpgsql
    AS $$
begin
    return QUERY select tr.current_height <= tm.tank_warning_level
                 from water_tank_readings as tr
                          join water_tanks_models tm on tr.tank_model_fk = tm.pk
                 where tr.pk = reading_pk;
end;
$$;


ALTER FUNCTION public.is_caution_level_water_level(reading_pk integer) OWNER TO postgres;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: drivers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.drivers (
    pk integer NOT NULL,
    username text,
    pin text
);


ALTER TABLE public.drivers OWNER TO postgres;

--
-- Name: managers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.managers (
    pk integer NOT NULL,
    username text,
    pin text
);


ALTER TABLE public.managers OWNER TO postgres;

--
-- Name: residents; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.residents (
    pk integer NOT NULL,
    username text,
    pin text,
    house_number text,
    water_tank_fk integer,
    sewage_tank_fk integer
);


ALTER TABLE public.residents OWNER TO postgres;

--
-- Name: app_login; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.app_login AS
 SELECT residents.username,
    residents.pin,
    'resident'::text AS user_type
   FROM public.residents
UNION
 SELECT drivers.username,
    drivers.pin,
    'driver'::text AS user_type
   FROM public.drivers
UNION
 SELECT managers.username,
    managers.pin,
    'manager'::text AS user_type
   FROM public.managers;


ALTER TABLE public.app_login OWNER TO postgres;

--
-- Name: companies; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.companies (
    pk integer NOT NULL,
    company_name text
);


ALTER TABLE public.companies OWNER TO postgres;

--
-- Name: complaint_types; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.complaint_types (
    pk integer NOT NULL,
    complaint_type text
);


ALTER TABLE public.complaint_types OWNER TO postgres;

--
-- Name: reports; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reports (
    pk integer NOT NULL,
    complaint_type_fk integer,
    company_fk integer,
    complaint text,
    "timestamp" timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.reports OWNER TO postgres;

--
-- Name: app_reports; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.app_reports AS
 SELECT r.pk,
    ct.complaint_type,
    c.company_name,
    r.complaint
   FROM ((public.reports r
     JOIN public.companies c ON ((r.company_fk = c.pk)))
     JOIN public.complaint_types ct ON ((r.complaint_type_fk = ct.pk)));


ALTER TABLE public.app_reports OWNER TO postgres;

--
-- Name: manager_worklist; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.manager_worklist (
    pk integer NOT NULL,
    resident_fk integer,
    time_estimate_fk integer,
    tank_type_fk integer,
    "timestamp" timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    completed boolean DEFAULT false
);


ALTER TABLE public.manager_worklist OWNER TO postgres;

--
-- Name: tank_types; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tank_types (
    pk integer NOT NULL,
    tank_type text
);


ALTER TABLE public.tank_types OWNER TO postgres;

--
-- Name: time_estimates; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.time_estimates (
    pk integer NOT NULL,
    estimate text
);


ALTER TABLE public.time_estimates OWNER TO postgres;

--
-- Name: app_worklist; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.app_worklist AS
 SELECT r.username,
    r.house_number,
    tt.tank_type,
    te.estimate,
    to_char(manager_worklist."timestamp", 'DD-Mon-YYYY HH:MM:SSPM'::text) AS "timestamp",
    manager_worklist.completed
   FROM (((public.manager_worklist
     JOIN public.residents r ON ((manager_worklist.resident_fk = r.pk)))
     JOIN public.time_estimates te ON ((manager_worklist.time_estimate_fk = te.pk)))
     JOIN public.tank_types tt ON ((manager_worklist.tank_type_fk = tt.pk)));


ALTER TABLE public.app_worklist OWNER TO postgres;

--
-- Name: companies_pk_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.companies_pk_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.companies_pk_seq OWNER TO postgres;

--
-- Name: companies_pk_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.companies_pk_seq OWNED BY public.companies.pk;


--
-- Name: complaint_types_pk_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.complaint_types_pk_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.complaint_types_pk_seq OWNER TO postgres;

--
-- Name: complaint_types_pk_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.complaint_types_pk_seq OWNED BY public.complaint_types.pk;


--
-- Name: drivers_pk_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.drivers_pk_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.drivers_pk_seq OWNER TO postgres;

--
-- Name: drivers_pk_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.drivers_pk_seq OWNED BY public.drivers.pk;


--
-- Name: manager_worklist_pk_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.manager_worklist_pk_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.manager_worklist_pk_seq OWNER TO postgres;

--
-- Name: manager_worklist_pk_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.manager_worklist_pk_seq OWNED BY public.manager_worklist.pk;


--
-- Name: managers_pk_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.managers_pk_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.managers_pk_seq OWNER TO postgres;

--
-- Name: managers_pk_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.managers_pk_seq OWNED BY public.managers.pk;


--
-- Name: message; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.message (
    pk integer NOT NULL,
    messages text,
    "timestamp" timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.message OWNER TO postgres;

--
-- Name: message_pk_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.message_pk_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.message_pk_seq OWNER TO postgres;

--
-- Name: message_pk_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.message_pk_seq OWNED BY public.message.pk;


--
-- Name: reports_pk_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.reports_pk_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.reports_pk_seq OWNER TO postgres;

--
-- Name: reports_pk_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.reports_pk_seq OWNED BY public.reports.pk;


--
-- Name: residents_pk_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.residents_pk_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.residents_pk_seq OWNER TO postgres;

--
-- Name: residents_pk_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.residents_pk_seq OWNED BY public.residents.pk;


--
-- Name: sewage_tank_readings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sewage_tank_readings (
    pk integer NOT NULL,
    status text,
    "timestamp" timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    tank_owner_fk integer,
    tank_model_fk integer
);


ALTER TABLE public.sewage_tank_readings OWNER TO postgres;

--
-- Name: sewage_tank_readings_pk_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sewage_tank_readings_pk_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sewage_tank_readings_pk_seq OWNER TO postgres;

--
-- Name: sewage_tank_readings_pk_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sewage_tank_readings_pk_seq OWNED BY public.sewage_tank_readings.pk;


--
-- Name: sewage_tanks_models; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sewage_tanks_models (
    pk integer NOT NULL,
    tank_model text,
    tank_height double precision,
    tank_width double precision,
    tank_length double precision,
    tank_warning_level double precision,
    tank_critical_level double precision
);


ALTER TABLE public.sewage_tanks_models OWNER TO postgres;

--
-- Name: sewage_tanks_models_pk_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sewage_tanks_models_pk_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sewage_tanks_models_pk_seq OWNER TO postgres;

--
-- Name: sewage_tanks_models_pk_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sewage_tanks_models_pk_seq OWNED BY public.sewage_tanks_models.pk;


--
-- Name: water_tank_readings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.water_tank_readings (
    pk integer NOT NULL,
    current_height double precision,
    "timestamp" timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    tank_owner_fk integer,
    tank_model_fk integer
);


ALTER TABLE public.water_tank_readings OWNER TO postgres;

--
-- Name: tank_readings_pk_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tank_readings_pk_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tank_readings_pk_seq OWNER TO postgres;

--
-- Name: tank_readings_pk_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tank_readings_pk_seq OWNED BY public.water_tank_readings.pk;


--
-- Name: tank_types_pk_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tank_types_pk_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tank_types_pk_seq OWNER TO postgres;

--
-- Name: tank_types_pk_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tank_types_pk_seq OWNED BY public.tank_types.pk;


--
-- Name: time_estimates_pk_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.time_estimates_pk_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.time_estimates_pk_seq OWNER TO postgres;

--
-- Name: time_estimates_pk_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.time_estimates_pk_seq OWNED BY public.time_estimates.pk;


--
-- Name: water_tanks_models; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.water_tanks_models (
    pk integer NOT NULL,
    tank_height double precision,
    tank_width double precision,
    tank_length double precision,
    tank_warning_level double precision,
    tank_critical_level double precision,
    tank_model text
);


ALTER TABLE public.water_tanks_models OWNER TO postgres;

--
-- Name: water_tanks_model_pk_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.water_tanks_model_pk_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.water_tanks_model_pk_seq OWNER TO postgres;

--
-- Name: water_tanks_model_pk_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.water_tanks_model_pk_seq OWNED BY public.water_tanks_models.pk;


--
-- Name: companies pk; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.companies ALTER COLUMN pk SET DEFAULT nextval('public.companies_pk_seq'::regclass);


--
-- Name: complaint_types pk; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.complaint_types ALTER COLUMN pk SET DEFAULT nextval('public.complaint_types_pk_seq'::regclass);


--
-- Name: drivers pk; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.drivers ALTER COLUMN pk SET DEFAULT nextval('public.drivers_pk_seq'::regclass);


--
-- Name: manager_worklist pk; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.manager_worklist ALTER COLUMN pk SET DEFAULT nextval('public.manager_worklist_pk_seq'::regclass);


--
-- Name: managers pk; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.managers ALTER COLUMN pk SET DEFAULT nextval('public.managers_pk_seq'::regclass);


--
-- Name: message pk; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.message ALTER COLUMN pk SET DEFAULT nextval('public.message_pk_seq'::regclass);


--
-- Name: reports pk; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reports ALTER COLUMN pk SET DEFAULT nextval('public.reports_pk_seq'::regclass);


--
-- Name: residents pk; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.residents ALTER COLUMN pk SET DEFAULT nextval('public.residents_pk_seq'::regclass);


--
-- Name: sewage_tank_readings pk; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sewage_tank_readings ALTER COLUMN pk SET DEFAULT nextval('public.sewage_tank_readings_pk_seq'::regclass);


--
-- Name: sewage_tanks_models pk; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sewage_tanks_models ALTER COLUMN pk SET DEFAULT nextval('public.sewage_tanks_models_pk_seq'::regclass);


--
-- Name: tank_types pk; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tank_types ALTER COLUMN pk SET DEFAULT nextval('public.tank_types_pk_seq'::regclass);


--
-- Name: time_estimates pk; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.time_estimates ALTER COLUMN pk SET DEFAULT nextval('public.time_estimates_pk_seq'::regclass);


--
-- Name: water_tank_readings pk; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.water_tank_readings ALTER COLUMN pk SET DEFAULT nextval('public.tank_readings_pk_seq'::regclass);


--
-- Name: water_tanks_models pk; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.water_tanks_models ALTER COLUMN pk SET DEFAULT nextval('public.water_tanks_model_pk_seq'::regclass);


--
-- Data for Name: companies; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.companies (pk, company_name) FROM stdin;
\.
COPY public.companies (pk, company_name) FROM '$$PATH$$/3079.dat';

--
-- Data for Name: complaint_types; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.complaint_types (pk, complaint_type) FROM stdin;
\.
COPY public.complaint_types (pk, complaint_type) FROM '$$PATH$$/3077.dat';

--
-- Data for Name: drivers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.drivers (pk, username, pin) FROM stdin;
\.
COPY public.drivers (pk, username, pin) FROM '$$PATH$$/3063.dat';

--
-- Data for Name: manager_worklist; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.manager_worklist (pk, resident_fk, time_estimate_fk, tank_type_fk, "timestamp", completed) FROM stdin;
\.
COPY public.manager_worklist (pk, resident_fk, time_estimate_fk, tank_type_fk, "timestamp", completed) FROM '$$PATH$$/3060.dat';

--
-- Data for Name: managers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.managers (pk, username, pin) FROM stdin;
\.
COPY public.managers (pk, username, pin) FROM '$$PATH$$/3061.dat';

--
-- Data for Name: message; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.message (pk, messages, "timestamp") FROM stdin;
\.
COPY public.message (pk, messages, "timestamp") FROM '$$PATH$$/3073.dat';

--
-- Data for Name: reports; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reports (pk, complaint_type_fk, company_fk, complaint, "timestamp") FROM stdin;
\.
COPY public.reports (pk, complaint_type_fk, company_fk, complaint, "timestamp") FROM '$$PATH$$/3075.dat';

--
-- Data for Name: residents; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.residents (pk, username, pin, house_number, water_tank_fk, sewage_tank_fk) FROM stdin;
\.
COPY public.residents (pk, username, pin, house_number, water_tank_fk, sewage_tank_fk) FROM '$$PATH$$/3065.dat';

--
-- Data for Name: sewage_tank_readings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sewage_tank_readings (pk, status, "timestamp", tank_owner_fk, tank_model_fk) FROM stdin;
\.
COPY public.sewage_tank_readings (pk, status, "timestamp", tank_owner_fk, tank_model_fk) FROM '$$PATH$$/3072.dat';

--
-- Data for Name: sewage_tanks_models; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sewage_tanks_models (pk, tank_model, tank_height, tank_width, tank_length, tank_warning_level, tank_critical_level) FROM stdin;
\.
COPY public.sewage_tanks_models (pk, tank_model, tank_height, tank_width, tank_length, tank_warning_level, tank_critical_level) FROM '$$PATH$$/3068.dat';

--
-- Data for Name: tank_types; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tank_types (pk, tank_type) FROM stdin;
\.
COPY public.tank_types (pk, tank_type) FROM '$$PATH$$/3056.dat';

--
-- Data for Name: time_estimates; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.time_estimates (pk, estimate) FROM stdin;
\.
COPY public.time_estimates (pk, estimate) FROM '$$PATH$$/3054.dat';

--
-- Data for Name: water_tank_readings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.water_tank_readings (pk, current_height, "timestamp", tank_owner_fk, tank_model_fk) FROM stdin;
\.
COPY public.water_tank_readings (pk, current_height, "timestamp", tank_owner_fk, tank_model_fk) FROM '$$PATH$$/3058.dat';

--
-- Data for Name: water_tanks_models; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.water_tanks_models (pk, tank_height, tank_width, tank_length, tank_warning_level, tank_critical_level, tank_model) FROM stdin;
\.
COPY public.water_tanks_models (pk, tank_height, tank_width, tank_length, tank_warning_level, tank_critical_level, tank_model) FROM '$$PATH$$/3070.dat';

--
-- Name: companies_pk_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.companies_pk_seq', 4, true);


--
-- Name: complaint_types_pk_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.complaint_types_pk_seq', 4, true);


--
-- Name: drivers_pk_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.drivers_pk_seq', 10, true);


--
-- Name: manager_worklist_pk_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.manager_worklist_pk_seq', 55, true);


--
-- Name: managers_pk_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.managers_pk_seq', 4, true);


--
-- Name: message_pk_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.message_pk_seq', 3, true);


--
-- Name: reports_pk_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.reports_pk_seq', 1, false);


--
-- Name: residents_pk_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.residents_pk_seq', 9, true);


--
-- Name: sewage_tank_readings_pk_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sewage_tank_readings_pk_seq', 4, true);


--
-- Name: sewage_tanks_models_pk_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sewage_tanks_models_pk_seq', 1, true);


--
-- Name: tank_readings_pk_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tank_readings_pk_seq', 97, true);


--
-- Name: tank_types_pk_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tank_types_pk_seq', 1, false);


--
-- Name: time_estimates_pk_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.time_estimates_pk_seq', 1, false);


--
-- Name: water_tanks_model_pk_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.water_tanks_model_pk_seq', 1, true);


--
-- Name: companies companies_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT companies_pk PRIMARY KEY (pk);


--
-- Name: complaint_types complaint_types_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.complaint_types
    ADD CONSTRAINT complaint_types_pk PRIMARY KEY (pk);


--
-- Name: drivers drivers_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.drivers
    ADD CONSTRAINT drivers_pk PRIMARY KEY (pk);


--
-- Name: managers managers_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.managers
    ADD CONSTRAINT managers_pk PRIMARY KEY (pk);


--
-- Name: message message_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.message
    ADD CONSTRAINT message_pk PRIMARY KEY (pk);


--
-- Name: manager_worklist pk_manager_worklist; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.manager_worklist
    ADD CONSTRAINT pk_manager_worklist PRIMARY KEY (pk);


--
-- Name: water_tank_readings pk_tank_readings; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.water_tank_readings
    ADD CONSTRAINT pk_tank_readings PRIMARY KEY (pk);


--
-- Name: tank_types pk_tank_types; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tank_types
    ADD CONSTRAINT pk_tank_types PRIMARY KEY (pk);


--
-- Name: time_estimates pk_time_estimates; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.time_estimates
    ADD CONSTRAINT pk_time_estimates PRIMARY KEY (pk);


--
-- Name: reports reports_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reports
    ADD CONSTRAINT reports_pk PRIMARY KEY (pk);


--
-- Name: residents residents_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.residents
    ADD CONSTRAINT residents_pk PRIMARY KEY (pk);


--
-- Name: sewage_tank_readings sewage_tank_readings_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sewage_tank_readings
    ADD CONSTRAINT sewage_tank_readings_pk PRIMARY KEY (pk);


--
-- Name: sewage_tanks_models sewage_tanks_models_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sewage_tanks_models
    ADD CONSTRAINT sewage_tanks_models_pk PRIMARY KEY (pk);


--
-- Name: water_tanks_models water_tanks_model_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.water_tanks_models
    ADD CONSTRAINT water_tanks_model_pk PRIMARY KEY (pk);


--
-- Name: companies_pk_uindex; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX companies_pk_uindex ON public.companies USING btree (pk);


--
-- Name: complaint_types_pk_uindex; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX complaint_types_pk_uindex ON public.complaint_types USING btree (pk);


--
-- Name: drivers_new_username_uindex; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX drivers_new_username_uindex ON public.drivers USING btree (username);


--
-- Name: drivers_pk_uindex; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX drivers_pk_uindex ON public.drivers USING btree (pk);


--
-- Name: managers_new_username_uindex; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX managers_new_username_uindex ON public.managers USING btree (username);


--
-- Name: managers_pk_uindex; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX managers_pk_uindex ON public.managers USING btree (pk);


--
-- Name: reports_pk_uindex; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX reports_pk_uindex ON public.reports USING btree (pk);


--
-- Name: residents_new_username_uindex; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX residents_new_username_uindex ON public.residents USING btree (username);


--
-- Name: residents_pk_uindex; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX residents_pk_uindex ON public.residents USING btree (pk);


--
-- Name: sewage_tank_readings_pk_uindex; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX sewage_tank_readings_pk_uindex ON public.sewage_tank_readings USING btree (pk);


--
-- Name: sewage_tanks_models_pk_uindex; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX sewage_tanks_models_pk_uindex ON public.sewage_tanks_models USING btree (pk);


--
-- Name: water_tanks_model_pk_uindex; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX water_tanks_model_pk_uindex ON public.water_tanks_models USING btree (pk);


--
-- Name: water_tank_readings add_to_sewage_worklist; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER add_to_sewage_worklist AFTER INSERT ON public.water_tank_readings FOR EACH ROW EXECUTE PROCEDURE public.add_to_sewage_worklist();


--
-- Name: water_tank_readings add_to_water_worklist; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER add_to_water_worklist AFTER INSERT ON public.water_tank_readings FOR EACH ROW EXECUTE PROCEDURE public.add_to_water_worklist();


--
-- Name: manager_worklist fk_manager_worklist_resident_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.manager_worklist
    ADD CONSTRAINT fk_manager_worklist_resident_fk FOREIGN KEY (resident_fk) REFERENCES public.residents(pk);


--
-- Name: manager_worklist fk_manager_worklist_time_estimate_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.manager_worklist
    ADD CONSTRAINT fk_manager_worklist_time_estimate_fk FOREIGN KEY (time_estimate_fk) REFERENCES public.time_estimates(pk);


--
-- Name: water_tank_readings fk_tank_readings_tank_models; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.water_tank_readings
    ADD CONSTRAINT fk_tank_readings_tank_models FOREIGN KEY (tank_model_fk) REFERENCES public.water_tanks_models(pk);


--
-- Name: water_tank_readings fk_tank_readings_tank_owner_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.water_tank_readings
    ADD CONSTRAINT fk_tank_readings_tank_owner_fk FOREIGN KEY (tank_owner_fk) REFERENCES public.residents(pk);


--
-- Name: manager_worklist manager_worklist_tank_types_pk_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.manager_worklist
    ADD CONSTRAINT manager_worklist_tank_types_pk_fk FOREIGN KEY (tank_type_fk) REFERENCES public.tank_types(pk);


--
-- Name: reports reports_companies_pk_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reports
    ADD CONSTRAINT reports_companies_pk_fk FOREIGN KEY (company_fk) REFERENCES public.companies(pk);


--
-- Name: reports reports_complaint_types_pk_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reports
    ADD CONSTRAINT reports_complaint_types_pk_fk FOREIGN KEY (complaint_type_fk) REFERENCES public.complaint_types(pk);


--
-- Name: residents residents_sewage_tanks_models_pk_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.residents
    ADD CONSTRAINT residents_sewage_tanks_models_pk_fk FOREIGN KEY (sewage_tank_fk) REFERENCES public.sewage_tanks_models(pk);


--
-- Name: residents residents_water_tanks_model_pk_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.residents
    ADD CONSTRAINT residents_water_tanks_model_pk_fk FOREIGN KEY (water_tank_fk) REFERENCES public.water_tanks_models(pk);


--
-- Name: sewage_tank_readings sewage_tank_readings_residents_pk_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sewage_tank_readings
    ADD CONSTRAINT sewage_tank_readings_residents_pk_fk FOREIGN KEY (tank_owner_fk) REFERENCES public.residents(pk);


--
-- Name: sewage_tank_readings sewage_tank_readings_sewage_tanks_models_pk_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sewage_tank_readings
    ADD CONSTRAINT sewage_tank_readings_sewage_tanks_models_pk_fk FOREIGN KEY (tank_model_fk) REFERENCES public.sewage_tanks_models(pk);


--
-- PostgreSQL database dump complete
--

